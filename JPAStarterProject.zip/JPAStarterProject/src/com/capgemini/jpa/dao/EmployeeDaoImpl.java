package com.capgemini.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.utility.JPAUtil;

public class EmployeeDaoImpl implements IEmployeeDAO {

	@Override
	public void addNewEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
	      EntityManager entityManager=null;
		try{
		entityManager=JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		employee.setEmpid(null);
		entityManager.persist(employee);
		entityManager.getTransaction().commit();
		}
		catch(PersistenceException e)
		{
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEmployee(Integer empid) throws EmployeeException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee getEmployeeDetails(Integer empid) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}
