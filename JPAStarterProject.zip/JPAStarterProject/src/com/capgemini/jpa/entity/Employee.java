package com.capgemini.jpa.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;




@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer empid;
	
	private String ename;
	private LocalDate hiredate;
	private String job;
	private Double salary;
	private Integer dept_no;
	
	public Employee(Integer empid, String ename, LocalDate hiredate,
			String job, Double salary, Integer dept_no) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.hiredate = hiredate;
		this.job = job;
		this.salary = salary;
		this.dept_no = dept_no;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public LocalDate getHiredate() {
		return hiredate;
	}
	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Integer getDept_no() {
		return dept_no;
	}
	public void setDept_no(Integer dept_no) {
		this.dept_no = dept_no;
	}
	
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", hiredate="
				+ hiredate + ", job=" + job + ", salary=" + salary
				+ ", dept_no=" + dept_no + "]";
	}

}
